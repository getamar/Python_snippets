'''Geocoding API - If Address is given they give the latitude and longitude

pip install googlemap
easy_install
easy install pip
sudo pip install googlemaps

sudo - gives the administrative privelages
pip - it installs 
pip freeze - this gives all package installed in the terminal
pip install pandas numpy scikit

'''

import googlemaps
import json

gmaps = googlemaps.Client(key='AIzaSyCCfnTSQ3g_QEQll192QDRKIV6dB9uw9hI')
geocode_results = gmaps.geocode('20 Ropemaker St, London EC2Y 9AR')
json_format = json.dumps(geocode_results, sort_keys=True, indent = 4, separators=(',' , ':'))

reverse_result = gmaps.reverse_geocode(40.71, -73.96)

"lat":51.37275020000001,
"lng":0.6203113

'''write 10 address and find the distance walking between all the address, store that in the csv 

and this can be sorted

Google Maps distance Matrix API

register again for this api too'''




