'''square_list = []
for i in range(0,5):
    temp = i**2
    square_list.append(temp)

print square_list

print [x**2 for x in range(0,5)]

print [x**2 + x**3 for x in range(0,6)]

[[x,x**2,x**3] for x in range(0,5)]'''

l = 'The quick brown fox jumps over the lazy dog'

if l.split(' ')[1] in ['a','e','i','o','u']:
    print l.split(' ')[1]

'''for l in l.split():
    print l'''

''' (the, THE, the, number of letters in word'''

'''print [[k, k.upper(), k.lower(), len(k)] for k in l.split(' ')]

print [1 for x in range(0,5)]

print [[k, k.upper(), k.lower(), len(k)] for k in l.split(' ') if k[1] not in ['a','e','i','o','u']]

print [(x,y) for x in range(0,11) for y in range(0,10)]'''

'''Pythogoran tuples'''

'''print [(x,y,z) for x in range(1,50) for y in range (x,50) for z in range(y,50) if (x**2 + y**2 == z**2)]'''

'''def my_square(x):
    return x**2

def my_even(x):
    if x%2 == 0:
        return True
    return False'''

''' Map functions is used to give a function name and the variables'''
'''print map(my_square, [1,2,3,4,5])'''

''' Filter is same Map functions '''
'''print filter(my_even, [1,2,3,4,5])'''

'''lambda are same as map function but you don't define the function instead make it as one tiem usable inside the lambda call'''
map(lambda x: x**2, [1,2,3,4,5])

def my_tupples(x):
    print x.lower(), x.upper(), len(x)

def my_vowel(x):
    if x[1] in ['a','e','i','o','u']:
        return True
    return False

map(my_tupples, filter(my_vowel,l.split(' ')))


map(lambda x: (x,x.upper(),x.lower(), len(x)), filter(lambda x: x[1] in ['a','e','i','o','u'], 'The quick brown fox jumps over the lazy dog'.split()))

print reduce(lambda x,y: x+y, [1,2,3,4,5])

''' Reduce function applies to the list recursively to get one output
x+y applied to 1+2 
then 3+3
then 6+4
then 10+5
'''
print reduce(lambda x,y: x+y, [1,2,3,4,5,6])

'''Write reduce 1 liner which returns the maximum number in list'''

def compare(x,y):
    if x > y:
        return x
    else:
        return y

print reduce(compare, [1,5,6,7,8,9])

print reduce(lambda x, y: x if (x > y) else y, [1,2,3,4,5,6,8])












