my_name = raw_input("Please insert your name")

while(True):
    my_name = raw_input("Please enter you name or enter exit to quit")
    if my_name == 'exit':
        print "Exiting Program. Bye \n"
        exit()
    print "Hello %s" %my_name