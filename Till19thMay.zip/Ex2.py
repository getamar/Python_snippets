#Write a function that takes distinct integers and returns the smallest one
def get_min(num1_in,num2_in,num3_in):
    if (num1_in < num2_in):
        if(num1_in< num3_in):
            return num1_in
        elif(num3_in < num2_in):
            return num3_in
        else:
            return num2_in

a = get_min(10,100,5)
print a

#Write a function that takes list of integers and finds the largest number in the list
def getMaxFromList(num_list):
    maxNum = num_list[0]
    for i in num_list:
        if maxNum < i:
            maxNum = i
    return maxNum

great = [123,456,1238980,0,9,4,343,234,6345,73453]
max_out = getMaxFromList(great)
print max_out

#Write a function that takes a list of integers and returns the total number of items in the list
def list_items(numList_in):
    counter_out = 0
    for i in numList_in:
        counter_out += 1
    return counter_out



#Write a function that takes a list of integers and returns the average
def getAverage(numList_in):
    counter = 0
    sum = 0
    for i in numList_in:
        sum += i
        counter += 1
    average_out = sum/counter
    return average_out

print list_items(great)
print getAverage(great)