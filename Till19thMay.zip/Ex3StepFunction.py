'''def recursive_sum(list_in):
    if list_in == []:
        return 0
    temp_list = list(list_in[1:])
    print temp_list
    return list_in[0] + recursive_sum(temp_list)

print recursive_sum([34,23,34,45])'''

#Write a function that takes a list of numbers and returns product of all numbers in the list

def recursiveProduct(list_in):
    if len(list_in)==1:
        return list_in[0]
    temp_list = list(list[1:])
    print temp_list
    return list_in[0] * recursiveProduct(temp_list)

num_product = [1,2,3,4,5]

print recursiveProduct(num_product)

'''print recursiveProduct([1,2,3,4,5])'''

