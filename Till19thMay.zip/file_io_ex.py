import sys, os

'''
new Linux commands: echo, redirect symbol and '>>' APPEND

head -n 2 filename.txt = reads only the first 2 lines of the file
tail -n 2 filename.txt = reads only the last 2 lines of the files

new python functions: open, close, file_name.read, file_name.write, rename(), remove()

'''

filename = 'filename.txt'
file = open(filename, "r")

''' Modify it to print last word of every line'''
line_number = 0
for line in file:
    words = line.split(" ")
    print "Last word of line %d: %s" %(line_number, words[-1])
    line_number += 1
file.close()

'''Write in a file open(fileout, "w+' == write + read
                                "a+" = append + read
                                
                                '''

fileout = "file2write.txt"
file = open(fileout, "a")
file.write("Hello world\n")
file.close()

'''Implement copy command in python'''
def my_cp(source_file, dest_file):
    file_read = open(source_file, 'r')
    file_out = open(dest_file, 'w')
    for line_list in file_read:
        file_out.write(line_list)
    file_out.close()
    file_read.close()
    return

def my_rm(source_file, dest_file):
    my_cp()
    os.remove(source_file)

def get_file_handle_details(file_hn_in):
    print "Name of the file:" %file_hn_in.name
    print "Is it closed? %s" %file_hn_in_closed
    print " Its mode is : %s" %file_hn_in.mode
    return

file_name = "file2write.txt"
my_hn = open(file2Write,'a+')
get_file_handle_details(my_hn)
my_hn.close()
get_file_handle_details(my_hn)



'''my_cp('filename.txt','file2write.txt')'''


''' remove (file_name)
    rename (file_name) '''
