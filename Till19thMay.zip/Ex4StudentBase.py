#Write a function that takes distinct integers and returns the smallest one
''' Write a program to get input from user
    4 inputs
    
    1.New
        New Amarnath 5 
    2.List
    3.Average
    4.Exit
     
    Each item should have 
        Name years Occupation
        
        student_db[]
        def print_users():
        def get_average():
        def enter_users():
        def exit_db():
'''

student_db = []

def getExit():
    exit()

def getEnter():

def getAverage():
    student_db

def getList():
    print student_db


while(True):

    print "you have following options"
    print "1. Enter \n2. List \n3. Average \n4. Exit\n"
    print "Enter Name YrExperience Occupation\n"

    raw_st = raw_input("please choose your option and enter it like below\n")
    split_st = raw_st.split(' ')
    print split_st

    if split_st[0] == 'Exit' or 'exit':
        getExit()








