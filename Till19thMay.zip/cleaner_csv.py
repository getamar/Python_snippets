import csvimport sys

f = open('mod.csv','rt')

reader = csv.reader(f)

all_rows[]
for row in reader:
    all_rows.append(row)

empty_line = ['', '','', '','', '']
dirty_line = ['', '','', '','', '','']
dirty_line2 = ['', '','', '','', '','', '']
dirty_lines = [empty_line,dirty_line,dirty_line2]

clean_empty_rows = []
for row in all_rows:
    if row in firty_lines:
        continue
    else:
        clean_empty_rows.append(row)

dirty_columns = [0,4,5,6]
clean_row_columns =[]
for row_in_clean_empty_rows:
    clean_row = []
    for i in range(0, len(row)):
        if i not in dirty.columns:
            clean_row.append(row[i])
        clean_row_columns.append(clean_row)

print "FULL CLEANED DATASET"
for i in clean_row_columns:
    print i