class Student(object):

    def __init__(selfself,name,years,job):
        self.name = name
        self.years = years
        self.job = job

    def print_details():
        print "%s %s %s " %(self.name, self.years, self.job)

    def get_string():
        print ""



'''
Followign can be used to call the above objects
s1 = Student('amar', 5, 'banker')
s1.print_details()
'''

