'''Write a program to get input from user'''

last_saved_file = "default.txt"

s1 = ['Amarnath',12,'Software Engineer']
s2 = ['Ahamed', 8, 'Medical']
s3 = ['Gareth', 10, 'Accountant']
s4 = ['Selena',10,'Analyst']
s5 = ['Amar',1,'Engineer']
s6 = ['Aham', 9, 'Medi']
s7 = ['Gare', 1, 'Accountant']
s8 = ['Sele',11,'Analyst']

student_default_db = (s1,s2,s3,s4,s5,s6,s7,s8)
student_db = list(student_default_db)


def getExit():
    exit()

def getNew():
    s3 = [split_st[1],split_st[2],split_st[3]]
    student_db.append(s3)

def getAverage():
    counter = 0
    sum = 0
    for _ in range(0, len(student_db)):
        sum = sum + int(student_db[counter][1])
        counter = counter + 1
    print sum/counter

def getPrint():
    counter = 0
    print len(student_db)
    if len(student_db) > 1:
        print "Student Name \t Exp \t Occupation\n"
        for i in range(0, len(student_db)):
            sub_counter = 0
            print "%s\t%s\t%s\t" %(student_db[counter][sub_counter],student_db[counter][sub_counter+1],student_db[counter][sub_counter+2])
            counter = counter + 1

def getDeleteAll():
    counter = 0
    for i in range(0, len(student_db)):
        for j in range(0, 3):
            student_db[counter].pop(-1)
        counter = counter + 1
    print student_db

def getDatabase():
    student_db = list(student_default_db)
    counter = 0
    for i in range(0, len(student_db)):
        sub_counter = 0
        print "%s\t%s\t%s\t" %(student_db[counter][sub_counter],student_db[counter][sub_counter+1],student_db[counter][sub_counter+2])
        counter = counter + 1

def Save():

    return



while (True):

    print "you have following options"
    print "1. New \n2. Print \n3. Average \n4. Deleteall \n5. Database \n6. Exit\n"
    raw_st = raw_input("please choose your option\n")
    split_st = raw_st.split(' ')

    if split_st[0].lower() == 'exit':
        getExit()
    elif split_st[0].lower() == 'print':
        getPrint()
    elif split_st[0].lower() == 'new':
        getNew()
    elif split_st[0].lower() == 'average':
        getAverage()
    elif split_st[0].lower() == 'deleteall':
        getDeleteAll()
    elif split_st[0].lower() == 'database':
        getDatabase()
    else:
        continue

    redundant = raw_input("hit enter to continue\n")