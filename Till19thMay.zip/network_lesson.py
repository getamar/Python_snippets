import httplib

'''conn = httplib.HTTPConnection("www.google.com")
conn.request("GET", '/index.html')'''
conn = httplib.HTTPConnection("www.bbc.com")
conn.request("GET", '/')

''' get response is eqv to 
    r1.read gives the complete read
    r1.status gives the status of the method/verb'''

r1 = conn.getresponse()
print r1.status, r1.reason, r1.read()

'''Below method is used as the string to store the whole web page in string format
thi string can be used for varous string methods and obtain the expected results'''
bbc_page = str(r1.read)

import urlib, urllib2

''' url len code method is used to encode the variaous parameters in http format like space is replaced as 
   %2B'''
params = urllib.urlencode({'q':'5+ 5my_que+ry','python':4,'occupation':'analyst'})

conn = httplib.HTTPConnection("www.google.com")

print params

''' When to try except is really required to make sure there is no problem in the code executed, if there is 
problem then the except block is run properly , so that the program conitnues rather than breaking the code'''

try:
    conn2 = httplib.HTTPConnection("www.python.com")
    conn2.request("POST", '/', params)
    response = conn2.request()
except:
    print'problem'


''' To make the problem defined following exceptiong is an example
except urllib2.HTTPError, Error'''



