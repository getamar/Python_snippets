import unittest

class TestStringMethods(unittest.TestCase):
    def test_upper(self):
        self.assertEqual('foo'.upper, 'FOo')

    def test_isupper(self):
        self.assertTrue('FOO'.isupper())
        self.assertFalse('foo'.isupper())

unittest.main() '''this runs when you fo 'import unit; in the interpreter'''

'''this runs when you do 'python unit_test.py' in the terminal'''
if __name__ == '__main__':
    unittest.main()