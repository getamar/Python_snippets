import csv
import sys

f = open('clean3.csv', 'rt')

'''reader = csv.reader(f.delimiter=' ')'''
reader = csv.reader(f)
f.close()

for row in reader:
    print row

f = open('write_me.csv','wt')
writer = csv.writer(f.delimiter='|')
for team in team_:
    writer.writerow(team)
f.close()

