import datetime
import time

'''print "Time in seconds since the epoch is %s" %time.time()
print "Current date and time:", datetime.datetime.now()
print "Another way to print current date and time: ", datetime.datetime.now().strftime("%y-%m-%d-%H-%M")'''

datetime.delta(days = 5)
datetime.delta(days = 1)

t = datetime.datetime.now()


today.timetuple()



