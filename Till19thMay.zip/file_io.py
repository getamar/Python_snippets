import sys
import os

def get_file_path(file_name):
    pathname = os.path.abspath(file_name)
    return pathname

def print_working_dir():
    print os.getcwd()
    return

def print_my_ls(dir_in):
    print os.listdir(dir_in)

print "Abs path: %s" %get_file_path(sys.argv[1])
print_working_dir()
print "Files in current directory:", print_my_ls(os.getcwd())

for temp_file in os.listdir(os.getcwd()):
    print os.path.abspath(temp_file)
