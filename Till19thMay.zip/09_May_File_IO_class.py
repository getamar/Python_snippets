import sys, os

'''
new Linux commands: echo, redirect symbol and '>>' APPEND

'''

filename = 'filename.txt'
file = open(filename, "r")
for line in file:
    print line

file.close()