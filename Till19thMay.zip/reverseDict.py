def reverse_my_dict(dict_in):
    my_dict = zip(dict_in.values(),dict_in.keys())
    print dict(my_dict)
    '''The above method is an issue if you have same values, converted nthe reverse keys becomes gone.'''

    '''  
    dict_reverse = { }
    dict_input = dict(dict_in)
    dict_input_values = dict_input.values()
    dict_input_keys = dict_input.keys()
    zip_list = zip(dict_input_values, dict_input_keys)
    dict_reverse = dict(zip_list)
    print dict_reverse
    
    '''

def reverse_smart(dict_in):
    '''Reverse the dictionary dict_in so that the items are the keys , if two keys have the same value or not unique, the \
     the function should return all the keys of the non-unique values
     
     eg: d.input = {'reni':'finance','selena':'finanace','ahmad':'instructor', 'syed':'engineer'}
         d.output = {'finance':['reni','selena'], 'instructor':['ahmed'], 'engineer' : ['syed'] }
         
         1. 
    '''

    my_dict = dict(dict_in)
    print my_dict.keys()
    print my_dict.values()
    my_list = zip(my_dict.values(),my_dict.keys())
    print my_list

    '''for my_dict.values() in my_dict.items():
        print my_dict_values'''


my_dict = {'amar': 1,'rama': 2, 'ahamad' : 1,'amar1': 2,'rama2': 5, 'ahamad' : 6}


reverse_smart(my_dict)

''' Ahamad function

def reverse_smart(dict_in):
    new_dict = {}
    for k in dict_in.keys():
        item_to_add = dict_in[k]
        if item_to_add in new_dict.keys():
            new_dict[item_to_add].append(k)
        else:
            new_dict[item_to_add] = [k]
    return new_dict
'''
