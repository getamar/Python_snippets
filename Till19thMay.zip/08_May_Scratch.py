list a = [1,2,3,4]
one,two,three,four = a

'''this should make the  variable assignment directly'''

sentence = ''

dir(' ')
dir(3)
help(''.index)


regular expression
import re
pattern = re.compile(r" [0-9]+")
''' find uk phone number from a file'''

shell commands

ls - list
touch - create
mkdir - make directory
cd - change directory
cp - copy file
pwd - print working directory
mv - move file1 file3

import sys

print sys.argv

import sys
import os

def print_file_path(file_name):
    pathname = os.path.abspath( file_name)
    return pathname

print print_file_path(sys.argv[1])
