''' Write a program to get input from user'''


student_default_db =    [['Amarnath',12,'Software Engineer'],
                         ['Ahamed', 8, 'Medical'],
                         ['Gareth', 10, 'Accountant'],
                         ['Selena',10,'Analyst'],
                         ['Amar',1,'Engineer'],
                         ['Aham', 9, 'Medi'],
                         ['Gare', 1, 'Accountant'],
                         ['Sele',11,'Analyst']]

student_db = list(student_default_db)

def getLoad():
    DB_FileName = "studentDbFile.csv"
    DB_READ_FH = open(DB_FileName, 'a+')
    DB_LIST = DB_READ_FH.read()
    print DB_LIST
    stud_db = DB_LIST.split("\n")
    DB_READ_FH.close()
    print stud_db
    return stud_db


def getExit():
    exit()

def getNew():
    s3 = [split_st[1],split_st[2],split_st[3]]
    student_db.append(s3)

def getAverage():
    counter = 0
    sum = 0.0
    for _ in range(0, len(student_db)):
        sum = sum + int(student_db[counter][1])
        counter = counter + 1
    print sum/counter

def getPrint():
    counter = 0
    print "There are %s records in the database" %(len(student_db))
    if len(student_db) > 1:
        print "Student Name \t Exp \t Occupation\n"
        for i in range(0, len(student_db)):
            print "%s\t%s\t%s\t" %(student_db[counter][0],student_db[counter][1],student_db[counter][2])
            counter = counter + 1

def getDeleteAll():
    counter = 0
    for i in range(0, len(student_db)):
        for j in range(0, 3):
            student_db[counter].pop(-1)
        counter = counter + 1
    print student_db

def getDatabase():
    student_db = list(student_default_db)
    counter = 0
    for i in range(0, len(student_db)):
        sub_counter = 0
        print "%s\t%s\t%s\t" %(student_db[counter][sub_counter],student_db[counter][sub_counter+1],student_db[counter][sub_counter+2])
        counter = counter + 1

def getSave():
    DB_FileName = "studentDbFile_out.csv"
    DB_OUT = open(DB_FileName, 'w+')
    counter = 0
    if len(student_db) > 1:
        print "Student Name;Exp;Occupation\n"
        for i in range(0, len(student_db)):
            sub_counter = 0
            DB_OUT.write("%s;%s;%s\n" %(student_db[counter][sub_counter],student_db[counter][sub_counter+1],student_db[counter][sub_counter+2]))
            counter = counter + 1
    DB_OUT.close()
    getPrint()

while (True):

    print "you have following options"
    print "1. New - eg. New J 20 Music\n" \
          "2. Print - eg. print \n" \
          "3. Average - eg. average or avg\n" \
          "4. Deleteall \n" \
          "5. Database \n" \
          "6. Save \n" \
          "7. Load  - Load file name should be 'studentDbFile.csv' in the same folder\n" \
          "8. Exit\n"
    raw_st = raw_input("please choose your option\n")
    split_st = raw_st.split(' ')
    command = split_st[0]

    if command.lower() == 'exit':
        getExit()
    elif command.lower() == 'print':
        getPrint()
    elif command.lower() == 'new':
        getNew()
    elif command.lower() == 'average' or command.lower() == 'avg':
        getAverage()
    elif command.lower() == 'deleteall':
        getDeleteAll()
    elif command.lower() == 'database':
        getDatabase()
    elif command.lower() == 'save':
        getSave()
    elif command.lower() == 'load':
        student_db.append(getLoad())
    else:
        continue

    redundant = raw_input("Actions done? If so hit enter to continue\n")