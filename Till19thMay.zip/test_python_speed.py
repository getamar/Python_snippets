import time

def test_python_speed():
    for _ in range(0,10):
        start_time = time.time()

        counter = 0
        duration = 0
        for i in range(0, 10000000):
            counter += 1

        end_time = time.time()
        duration = duration +(end_time - start_time)
        print counter

    average = duration/10.0

    print " Python executed in 10 cycle average is %s " %duration

'''test_python_speed()'''


def test_python_speed():

    start_time = time.time()

    counter = 0
    for i in range(0, 10000000):
        counter += 1

    time_after_1st_loop = time.time()

    counter2 = 0
    for i in range(0, 200000):
        counter -= 1

    time_after_2nd_loop = time.time()

    duration_of_first_part = time_after_1st_loop - start_time
    duration_of_second_part = time_after_2nd_loop - time_after_1st_loop

    print duration_of_first_part, duration_of_second_part

test_python_speed()
