list1 = [1,2,3,4,5,6,7]
print list1[3:]
print list1[-3]
print list1[0::2]
print list1[1::2]
print list1[::-1]

list2 = list1
list1.append(8)

print list2

list2 = [x for x in list1]
list2 = list(list1)
list2 = list1[:]

'''enum'''
list1 = []

'''Flattening'''
big_list = [[1,2,3],[4,5,6],[7,8,9],[10,11,12]]
print [i for l in big_list for i in l]
print [item for sub_list in big_list for item in sub_list]


